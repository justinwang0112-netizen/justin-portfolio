# Justin Wang — Personal Portfolio

A simple, responsive finance-focused portfolio built for GitHub Pages.

## Before publishing

1. Optionally add your verified email address or LinkedIn URL to `index.html` before publishing. All included navigation links work without this.
2. Review the content, including the Project Hoops figure and descriptions. Make any corrections needed so the website reflects your experience accurately.
3. Optional: add a verified LinkedIn profile or project links to the project cards if you have them. Do not add placeholder links that lead nowhere.

## Publish with GitHub Pages

1. Sign into https://github.com and click **+ → New repository**.
2. Name the repository `justin-portfolio` (or another name). Select **Public**, then **Create repository**.
3. Click **Add file → Upload files**. Upload `index.html` and `styles.css` from this folder (not the ZIP itself), then **Commit changes**.
4. Open **Settings → Pages**, select **Deploy from a branch**, choose **main** and **/(root)**, then **Save**.
5. Once GitHub finishes publishing, the site will usually be at `https://YOUR-USERNAME.github.io/justin-portfolio/` (replace YOUR-USERNAME with your actual GitHub username and use your repository name).
6. Open that URL to check that the site works. Submit both the public repo link and the live website link to your class.

Repository URL format: `https://github.com/YOUR-USERNAME/justin-portfolio`

**Note:** I did not have access to the course video `Github Setup.mov`, so these instructions use GitHub's standard Pages setup and might not exactly match your instructor's video.
